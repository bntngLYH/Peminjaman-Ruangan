<?php
    // Konfigurasi koneksi database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ithcm";

    // Membuat koneksi ke database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
    }

    // Mengambil data dari input POST
    $kodeuser = isset($_POST['kodeuser']) ? trim($_POST['kodeuser']) : null;
    $password = isset($_POST['password']) ? trim($_POST['password']) : null;

    // Validasi input
    if (is_null($kodeuser) || is_null($password) || $kodeuser === "" || $password === "") {
        echo json_encode(["status" => "error", "message" => "Kodeuser dan password wajib diisi"]);
        exit;
    }

    // Query untuk memeriksa kombinasi kodeuser dan password menggunakan prepared statements
    $stmt = $conn->prepare("SELECT * FROM user WHERE kodeuser = ? AND password = ?");
    $stmt->bind_param("ss", $kodeuser, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        // Jika tidak ada hasil, periksa apakah kodeuser ada di database
        $stmt_check_kodeuser = $conn->prepare("SELECT * FROM user WHERE kodeuser = ?");
        $stmt_check_kodeuser->bind_param("s", $kodeuser);
        $stmt_check_kodeuser->execute();
        $check_kodeuser = $stmt_check_kodeuser->get_result();

        if ($check_kodeuser->num_rows === 0) {
            echo json_encode(["status" => "error", "message" => "Akun tidak terdaftar"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Password tidak cocok"]);
        }
        $stmt_check_kodeuser->close();
    } else {
        // Jika ada hasil, berarti login berhasil
        session_start();

        $row = $result->fetch_assoc();
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['nama'] = $row['nama'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['status'] = $row['status'];
        $_SESSION['kodeuser'] = $row['kodeuser'];
        $_SESSION['jurusan'] = $row['jurusan'];
        $_SESSION['prodi'] = $row['prodi'];

        echo json_encode(["status" => "success", "message" => "Login berhasil"]);
    }

    // Tutup statement dan koneksi
    $stmt->close();
    $conn->close();
?>
